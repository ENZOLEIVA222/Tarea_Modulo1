/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_modulo1;

/**
 *
 * @author DELL
 */
public class Ejercicio4 {
    
     public static void main(String[] args) {
        String[] nombres = {"Alejandra Maria Lopez",
            "Cesar Jose Lopez Rivera",
            "David Antonio Flores",
            "Jose Ernesto Alfaro",
            "Laura Yaneli Castillo",
            "Cindy Niskoca Baca Ramos",
            "Mairon Alejandro Lopez",
            "Rebeca Fortin Reyes",
            "Pedro Caleb Castro",
            "Wilmer Alexander"};
        for (int i = 0; i < 10; i++) {
            System.out.println(nombres[i]);
        }
    }
}
